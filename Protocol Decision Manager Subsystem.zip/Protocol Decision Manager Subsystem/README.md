"# Protocol-Dissector-Generator-System"

Protocol Decision Manager Subsystem

This subsystem is in charge of creating, editing, and maintaining the data structure that
represents the Protocol Decision Tree. 
 
"# Protocol-Dissector-Generator-System" 
